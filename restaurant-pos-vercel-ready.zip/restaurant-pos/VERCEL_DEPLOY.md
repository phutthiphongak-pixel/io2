# Deploy ร้านอาหารบน Vercel

โปรเจกต์นี้เตรียมให้ Flask ทำงานบน Vercel และสร้าง QR โต๊ะด้วย URL สาธารณะอัตโนมัติ

## QR URL ทำงานอย่างไร

- เมื่อรันบน Vercel: ใช้ `VERCEL_PROJECT_PRODUCTION_URL` เป็น URL หลักของ QR
- ถ้ายังไม่มี production URL: ใช้ `VERCEL_URL`
- ถ้าตั้ง `PUBLIC_BASE_URL`: ใช้ค่านี้ก่อนทุกอย่าง เหมาะกับ custom domain
- เมื่อรัน Flask ใน VS Code: ยังมี fallback สำหรับ local/LAN เพื่อทดสอบ

ตัวอย่าง QR ที่สร้างบน Vercel:

`https://my-restaurant.vercel.app/customer/table/1/scan?token=...`

ลูกค้าใช้ 4G/5G หรือ Wi-Fi คนละเครือข่ายกับร้านได้ เพราะ QR ชี้ไปยัง public URL ของ Vercel

## Deploy ผ่าน GitHub + Vercel

1. สร้าง repository แล้วอัปโหลดโฟลเดอร์โปรเจกต์นี้
2. ใน Vercel เลือก **Add New Project** แล้ว Import repository
3. ไม่ต้องตั้ง Build Command พิเศษสำหรับ Flask รุ่นปัจจุบันของ Vercel
4. ตั้ง Environment Variable:
   - `SECRET_KEY` = ค่าสุ่มยาว ๆ
   - `PUBLIC_BASE_URL` = เว้นว่างได้ เพราะระบบจะใช้ Vercel URL อัตโนมัติ
5. Deploy
6. เปิด URL ที่ Vercel ให้มา แล้วเข้าสู่ระบบผู้ดูแล
7. ไปที่จัดการโต๊ะและตรวจ QR ของแต่ละโต๊ะ

Vercel จะให้ deployment URL สาธารณะอัตโนมัติ และ Flask รองรับการ deploy บน Vercel โดยตรง

## สำคัญเรื่องฐานข้อมูล

เวอร์ชันนี้ยังใช้ SQLite เพื่อให้เปิดใน VS Code ได้ง่าย ฐานข้อมูลบน Vercel ถูกวางไว้ใน `/tmp` ตามโค้ดปัจจุบัน ซึ่งเหมาะกับเดโม/ทดสอบมากกว่าระบบร้านที่ต้องเก็บข้อมูลถาวร

ก่อนใช้งานจริง ควรย้ายฐานข้อมูลไปยัง PostgreSQL เช่น Vercel Postgres/Neon/Supabase และเก็บ `DATABASE_URL` เป็น Environment Variable
